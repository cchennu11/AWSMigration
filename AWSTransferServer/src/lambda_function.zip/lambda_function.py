import json
import boto3
from io import BytesIO
import zipfile
from datetime import date

def lambda_handler(event, context):
    print(event)
    s3_resource = boto3.resource('s3')
    for each_record in event['Records']:
        bucket_name = each_record['s3']['bucket']['name']
        file = each_record['s3']['object']['key']
        print(bucket_name)
        print(file)
        if(str(file).endswith('.zip')):
            print(file)
            zip_obj = s3_resource.Object(bucket_name=bucket_name, key=file)
            print(zip_obj)
            buffer = BytesIO(zip_obj.get()["Body"].read())
            z = zipfile.ZipFile(buffer)
            print(z)
            for filename in z.namelist():
                file_info = z.getinfo(filename)
                print(file_info)
                try:
                    today = date.today()
                    todays_date = today.strftime("%m-%d-%y")
                    response = s3_resource.meta.client.upload_fileobj(z.open(filename),Bucket=bucket_name,Key=todays_date + "/" + f'{filename}')
                    print(response)
                except Exception as e:
                    print(e)
            if response is None:
                s3_resource.Object(bucket_name, file).delete()
                print("Delete Success ")
            else:
                print("Not Deleted")
        else:
            print(file+ ' is not a zip file.')
